<?php
$host="comp-server.uhi.ac.uk"; // Host IP
$db_username="YOUR_USERNAME"; // Mysql username (your student number)
$db_password="YOUR_PASSWORD"; // Mysql password (look for it on E-Commerce Brightspace)
$db_name="YOUR_DATABASE_NAME"; // Database name (look for it on E-Commerce Brightspace)

// Create connection
$conn = new mysqli($host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
};
?>
