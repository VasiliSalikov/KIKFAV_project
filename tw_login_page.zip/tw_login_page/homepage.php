<?php
	session_start();

	if ($_SESSION['loggedin']=='yes'){
		echo 'Logged in!';
	}else{
		header('location:login.html');
	};

?>

<html>
	<head>
		<title>Test Homepage</title>
	</head>
	<body>
		yay.
	</body>
</html>

